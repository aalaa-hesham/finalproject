import 'package:provider/provider.dart';
class contact {
  final  String name;
  final String tel;
  contact({required this.name, required this.tel});


}